# HAYES OVERLAYS Android project

HAYES OVERLAYS is a native Android starter app with:
- Device RAM, internal storage and battery readouts
- Shortcuts to Android battery and storage settings
- Configurable crosshair overlay (size and five colours)
- Accessibility-based repeated centre tapping

## Compatibility
- Minimum Android 8.0 (API 26)
- Target Android 15 / API 35
- Designed for phones and tablets; actual overlay support depends on Android version and manufacturer.

## Build an APK
1. Install Android Studio on a computer.
2. Open this folder as an existing Gradle project.
3. Let Gradle sync and install Android SDK Platform 35 if prompted.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Install the generated APK on your Android device.

## First-run setup
- For the crosshair, allow **Display over other apps**.
- For auto-clicking, enable HAYES OVERLAYS under **Settings > Accessibility > Installed apps/services**.
- Start and stop tapping from the app. It taps the screen centre every 150 ms while running.

## Limitations and safety
Android does not expose a general-purpose "speed up CPU" API. The app reports device status and opens built-in settings rather than pretending to perform unsafe memory cleaning or overclocking.
The crosshair is a simple visual overlay, not an aiming aid. Some games (including competitive games) may block overlays or prohibit them under their rules. Do not use it where game rules disallow it.
Auto-clicking can violate individual apps' or games' rules. Use only where permitted. Disable the Accessibility service when not using it.

This is a source project, not a signed, ready-to-install APK. A computer with Android Studio/SDK is needed to compile it.
