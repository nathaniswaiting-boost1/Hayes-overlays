package com.hayes.overlays;
import android.app.Service; import android.content.Intent; import android.graphics.*; import android.os.IBinder; import android.view.*;
public class CrosshairService extends Service {
 public static boolean active=false; static int size=42,color=Color.GREEN; WindowManager wm; CrossView view;
 public static void update(int s,int c){size=s;color=c;}
 public void onCreate(){super.onCreate();wm=(WindowManager)getSystemService(WINDOW_SERVICE);view=new CrossView();WindowManager.LayoutParams p=new WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);wm.addView(view,p);active=true;}
 public int onStartCommand(Intent i,int f,int id){return START_STICKY;}
 public void onDestroy(){active=false;if(view!=null)wm.removeView(view);super.onDestroy();}
 public IBinder onBind(Intent i){return null;}
 class CrossView extends View {Paint p=new Paint(3);CrossView(){super(CrosshairService.this);setLayerType(View.LAYER_TYPE_SOFTWARE,null);} protected void onDraw(Canvas c){super.onDraw(c);float x=getWidth()/2f,y=getHeight()/2f,r=size*getResources().getDisplayMetrics().density/2f; p.setColor(color);p.setStrokeWidth(Math.max(2,r/12));p.setStyle(Paint.Style.STROKE); c.drawCircle(x,y,r/2,p);p.setStyle(Paint.Style.FILL);c.drawCircle(x,y,Math.max(2,r/15),p);p.setStrokeWidth(Math.max(2,r/10));c.drawLine(x-r,y,x-r/3,y,p);c.drawLine(x+r/3,y,x+r,y,p);c.drawLine(x,y-r,x,y-r/3,p);c.drawLine(x,y+r/3,x,y+r,p);}}
}
