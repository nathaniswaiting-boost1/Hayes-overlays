package com.hayes.overlays;
import android.accessibilityservice.AccessibilityService; import android.accessibilityservice.GestureDescription; import android.graphics.Path; import android.os.Handler; import android.view.accessibility.AccessibilityEvent;
public class TapAccessibilityService extends AccessibilityService {
 public static TapAccessibilityService instance; public boolean running=false; Handler h=new Handler();
 public void onServiceConnected(){instance=this;}
 public void onAccessibilityEvent(AccessibilityEvent e){}
 public void onInterrupt(){stop();}
 public void toggle(){if(running)stop();else{running=true;tap();}}
 void stop(){running=false;h.removeCallbacksAndMessages(null);}
 void tap(){if(!running)return;Path p=new Path();float x=getResources().getDisplayMetrics().widthPixels/2f,y=getResources().getDisplayMetrics().heightPixels/2f;p.moveTo(x,y);GestureDescription.StrokeDescription s=new GestureDescription.StrokeDescription(p,0,45);dispatchGesture(new GestureDescription.Builder().addStroke(s).build(),null,null);h.postDelayed(this::tap,150);}
 public void onDestroy(){stop();instance=null;super.onDestroy();}
}
