package com.hayes.overlays;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.provider.Settings;
import android.app.ActivityManager;
import android.os.StatFs;
import android.view.*;
import android.widget.*;
import java.util.Locale;

public class MainActivity extends Activity {
    int accent = Color.rgb(0,220,255);
    int crossColor = Color.GREEN;
    int crossSize = 42;
    TextView ram, storage, battery, status;
    LinearLayout root;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(8,12,24));
        getWindow().setNavigationBarColor(Color.rgb(8,12,24));
        build();
    }
    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density);}
    TextView label(String s,int size){ TextView t=new TextView(this); t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(size); t.setTypeface(null,Typeface.BOLD); return t; }
    void build(){
        ScrollView scroll=new ScrollView(this); root=new LinearLayout(this); root.setOrientation(1); root.setPadding(dp(20),dp(26),dp(20),dp(24)); root.setBackgroundColor(Color.rgb(8,12,24)); scroll.addView(root); setContentView(scroll);
        root.addView(label("HAYES OVERLAYS",28));
        TextView sub=new TextView(this); sub.setText("GAMING TOOLS  •  DEVICE CARE"); sub.setTextColor(accent); sub.setTextSize(11); root.addView(sub);
        addGap(18); cardTitle("DEVICE PERFORMANCE");
        ram=info("RAM","Checking…"); storage=info("STORAGE","Checking…"); battery=info("BATTERY","Checking…"); refreshStats();
        button("Refresh device information",()->refreshStats());
        button("Open Android battery settings",()->startActivity(new Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)));
        button("Open storage settings",()->startActivity(new Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)));
        addGap(14); cardTitle("GAMING CROSSHAIR");
        status=info("CROSSHAIR","Off");
        button("Enable / disable crosshair",()->toggleCrosshair());
        TextView sizeLabel=new TextView(this); sizeLabel.setText("Crosshair size"); sizeLabel.setTextColor(Color.LTGRAY); root.addView(sizeLabel);
        SeekBar size=new SeekBar(this); size.setMax(90); size.setProgress(crossSize-10); size.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean u){crossSize=p+10; CrosshairService.update(crossSize,crossColor);} public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){}}); root.addView(size);
        TextView colors=new TextView(this); colors.setText("Colour"); colors.setTextColor(Color.LTGRAY); root.addView(colors);
        LinearLayout row=new LinearLayout(this); root.addView(row);
        addColor(row,"Green",Color.GREEN); addColor(row,"Cyan",Color.CYAN); addColor(row,"Red",Color.RED); addColor(row,"White",Color.WHITE); addColor(row,"Yellow",Color.YELLOW);
        addGap(14); cardTitle("AUTO CLICKER");
        info("HOW IT WORKS","Uses Android Accessibility to repeat taps at the screen centre. Enable the service, then start it here.");
        button("Open Accessibility settings",()->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        button("Start / stop auto clicker",()->{
            if(TapAccessibilityService.instance!=null){ TapAccessibilityService.instance.toggle(); toast(TapAccessibilityService.instance.running?"Auto clicker started":"Auto clicker stopped"); }
            else toast("Enable HAYES OVERLAYS in Accessibility settings first.");
        });
        addGap(12); TextView note=new TextView(this); note.setText("Device care: Android does not allow apps to magically boost CPU speed or safely kill every background process. HAYES OVERLAYS shows real device information and links to built-in settings. Crosshair overlays may be blocked or disallowed by some games."); note.setTextColor(Color.GRAY); note.setTextSize(12); root.addView(note);
    }
    void addColor(LinearLayout row,String name,int c){ Button b=new Button(this); b.setText(name); b.setTextSize(10); b.setTextColor(c); b.setOnClickListener(v->{crossColor=c;CrosshairService.update(crossSize,crossColor);}); row.addView(b,new LinearLayout.LayoutParams(0,dp(48),1));}
    TextView info(String k,String v){TextView t=new TextView(this);t.setText(k+"   •   "+v);t.setTextColor(Color.WHITE);t.setTextSize(14);t.setPadding(0,dp(9),0,dp(9));root.addView(t);return t;}
    void cardTitle(String s){TextView t=label(s,15);t.setTextColor(accent);root.addView(t);addGap(5);}
    void addGap(int h){View v=new View(this);root.addView(v,new LinearLayout.LayoutParams(1,dp(h)));}
    void button(String s,Runnable r){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(Color.WHITE);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(24,39,65)));b.setOnClickListener(v->r.run());root.addView(b,new LinearLayout.LayoutParams(-1,dp(52)));addGap(5);}
    void refreshStats(){
        ActivityManager.MemoryInfo mi=new ActivityManager.MemoryInfo(); ((ActivityManager)getSystemService(ACTIVITY_SERVICE)).getMemoryInfo(mi);
        long total=mi.totalMem/1048576, avail=mi.availMem/1048576;
        ram.setText("RAM   •   "+avail+" MB available / "+total+" MB");
        StatFs fs=new StatFs(android.os.Environment.getDataDirectory().getPath()); long free=fs.getAvailableBytes()/1073741824L, all=fs.getTotalBytes()/1073741824L;
        storage.setText("STORAGE   •   "+free+" GB free / "+all+" GB");
        Intent i=registerReceiver(null,new android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if(i!=null){int level=i.getIntExtra("level",-1),scale=i.getIntExtra("scale",100);battery.setText("BATTERY   •   "+(level*100/Math.max(scale,1))+"%");}
    }
    void toggleCrosshair(){
        if(!Settings.canDrawOverlays(this)){Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()));startActivity(i);toast("Allow display over other apps, then tap enable again.");return;}
        if(CrosshairService.active){stopService(new Intent(this,CrosshairService.class));status.setText("CROSSHAIR   •   Off");}
        else {CrosshairService.update(crossSize,crossColor);startService(new Intent(this,CrosshairService.class));status.setText("CROSSHAIR   •   On");}
    }
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    @Override protected void onResume(){super.onResume();if(root!=null)refreshStats();}
}
